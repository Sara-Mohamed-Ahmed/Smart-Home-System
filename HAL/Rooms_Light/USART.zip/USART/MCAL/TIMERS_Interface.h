/*
 * TIMERS_Interface.h
 *
 *  Created on: Aug 8, 2024
 *      Author: hp
 */

#ifndef MCAL_TIMERS_INTERFACE_H_
#define MCAL_TIMERS_INTERFACE_H_

//normal mode
void TIM0_voidNormalMode(void);
void TIM0_voidNormalSetCallBack(void(*copy_pf)(void));


//CTC mode
void TIM0_voidCTCMode(void);
void TIM0_voidCTCSetCallBack(void(*copy_pf)(void));

#endif /* MCAL_TIMERS_INTERFACE_H_ */
