#include "../LIB/STD_Types.h"
#include "../LIB/BIT_MATH.h"
#include "DIO_Interface.h"
#include "GIE_Interface.h"
#include "Timers_Interface.h"
#include "USART_Interface.h"

int main() {
    // Set PORTD for USART communication
    DIO_voidSetPinDirection(DIO_u8_PORTD, DIO_u8_PIN0, DIO_u8_INPUT);  // RX
    DIO_voidSetPinDirection(DIO_u8_PORTD, DIO_u8_PIN1, DIO_u8_OUTPUT); // TX

    // Set all pins of PORTA as output for the LEDs
    DIO_voidSetPortDirection(DIO_u8_PORTA, DIO_u8_OUTPUT);

    USART_voidInit();
    u8 Local_u8Value;

    while (1) {
        Local_u8Value = USART_voidRecieveByte();

        switch (Local_u8Value) {
            case 'a':
                // Turn on the first LED (connected to PA0)
                DIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_HIGH);
                break;
            case 'b':
                // Turn on the second LED (connected to PA1)
                DIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_HIGH);
                break;
            case 'c':
                // Turn on the third LED (connected to PA2)
                DIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_HIGH);
                break;
            case 'd':
                // Turn on the fourth LED (connected to PA3)
                DIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_HIGH);
                break;
            case 'A':
                // Turn off the first LED (connected to PA0)
                DIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN0, DIO_u8_LOW);
                break;
            case 'B':
                // Turn off the second LED (connected to PA1)
                DIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN1, DIO_u8_LOW);
                break;
            case 'C':
                // Turn off the third LED (connected to PA2)
                DIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN2, DIO_u8_LOW);
                break;
            case 'D':
                // Turn off the fourth LED (connected to PA3)
                DIO_voidSetPinValue(DIO_u8_PORTA, DIO_u8_PIN3, DIO_u8_LOW);
                break;
            default:

                break;
        }
    }
}
