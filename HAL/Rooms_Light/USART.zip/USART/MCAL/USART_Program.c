/*
 * USART_Program.c
 *
 *  Created on: Aug 12, 2024
 *      Author: hp
 */

#include "../LIB/STD_TYPES.h"
#include "../LIB/BIT_MATH.h"
#include "USART_Config.h"
#include "USART_Interface.h"
#include "USART_Private.h"

void USART_voidInit(void){
	u16 Local_u8BaudRate=51;
	u8 	Local_u8UCSRC_value=0b10000000;

	//SELECT BAUD RATE
	USART_u8_UBRRL=(u8)Local_u8BaudRate;
	USART_u8_UBRRH=(u8)Local_u8BaudRate>>8;

	// disable for multi processor mode
	CLR_BIT(USART_u8_UCSRA,0);
	// enable the hardware prepheral
	SET_BIT(USART_u8_UCSRB,3);
	SET_BIT	(USART_u8_UCSRB,4);
	// character size (select 8 bit)
	CLR_BIT(USART_u8_UCSRB,2);
	SET_BIT(Local_u8UCSRC_value,2);
	SET_BIT(Local_u8UCSRC_value,1);
	//SEELCT ASYNCH
	CLR_BIT(USART_u8_UCSRC,6);
	// DISABLE PARITY BIT
	CLR_BIT(USART_u8_UCSRC,4);
	CLR_BIT(USART_u8_UCSRC,5);
	// SELECT ONE STOP BIT
	CLR_BIT(USART_u8_UCSRC,3);
	USART_u8_UCSRC=Local_u8UCSRC_value;
}


void USART_voidSendByte(u8 Copy_u8Byte){
while (GET_BIT(USART_u8_UCSRA,6)==0);
USART_u8_UDR=Copy_u8Byte;
}


u8 USART_voidRecieveByte(void){

	while (GET_BIT(USART_u8_UCSRA,7)==0);
return USART_u8_UDR;


}
