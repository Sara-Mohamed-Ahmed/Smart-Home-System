/*
 * USART_Interface.h
 *
 *  Created on: Aug 12, 2024
 *      Author: hp
 */

#ifndef MCAL_USART_INTERFACE_H_
#define MCAL_USART_INTERFACE_H_

void USART_voidInit(void);
void USART_voidSendByte(u8 Copy_u8Byte);
u8 USART_voidRecieveByte(void);

#endif /* MCAL_USART_INTERFACE_H_ */
