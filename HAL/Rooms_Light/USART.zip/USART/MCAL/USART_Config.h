/*
 * USART_Config.h
 *
 *  Created on: Aug 12, 2024
 *      Author: hp
 */

#ifndef MCAL_USART_CONFIG_H_
#define MCAL_USART_CONFIG_H_



#endif /* MCAL_USART_CONFIG_H_ */
